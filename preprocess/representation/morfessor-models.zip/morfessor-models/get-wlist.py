import re

# function: to get word list of original file. repeated words exist.
# out: e.g., English-wlist

def readFile(fname):
    with open(fname, "r") as f:
        fc = f.read()
        fc = fc.split("\n")
    return fc


def write_data_to_files(data, path):
    with open(path, "w") as s:
        for item in data:
            for w in item:
                s.write(w+"\n")


# to word list, words separated by <s>
def chas2w(sent):
    sent = re.split("<s>", sent)
    w_list = []
    for w in sent:
        w = w.strip()
        if len(w) == 0:
            continue
        w = ''.join(c for c in w.split())
        w_list.append(w)
    return w_list


def remove_repeat_sent(data):
    outer = []
    for line in data:
        word_list = []
        try:
            lc = line.split("\t")
            surface_form = lc[0]
            sentence = lc[3]
            cs = sentence.split("<SURFACE_FORM>")
            for w in chas2w(cs[0]):
                word_list.append(w)
            word_list.append(surface_form)
            for w in chas2w(cs[1]):
                word_list.append(w)
        except:
            pass
        if word_list not in outer:
            outer.append(word_list)
    return outer


if __name__ == '__main__':
    lang_list = ["English", "Spanish", "Turkish", "Arabic", "Indonesian"]

    for lang in lang_list:
        fname = "../selectedUDT-v2.1/UD_{}/train".format(lang)
        data = readFile(fname)
        data = remove_repeat_sent(data)
        wlist_path = "wlist-for-train/" + lang + '-wlist'
        write_data_to_files(data, wlist_path)




