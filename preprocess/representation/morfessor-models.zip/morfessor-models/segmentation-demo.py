import morfessor
io = morfessor.MorfessorIO()

for lang in ["English", "Spanish", "Turkish", "Arabic", "Indonesian"]:
    print("+++++++++++++++++{}".format(lang))
    model = io.read_binary_model_file('model-{}.segm.bi'.format(lang))

    words = ['words', 'segmenting', 'morfessor', 'unsupervised', "radical" ]

    for word in words:
        print(model.viterbi_segment(word))