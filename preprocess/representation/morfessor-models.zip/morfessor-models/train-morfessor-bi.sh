languages="Indonesian English Arabic Turkish Spanish"

for lang in ${languages}
do
  morfessor -t wlist-for-train/${lang}-wlist -s model-${lang}.segm.bi
done

#-s <file>
#save Binary model
#-S <file>
#save Morfessor 1.0 style text model
#--save-reduced
#save Reduced Binary model


#morfessor -t English-wlist -S model-en.segm -T test.txt